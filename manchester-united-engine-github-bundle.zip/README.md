# Manchester United Ideal 11 & Financial Feasibility Engine

An interactive, zero-budget (`$0.00 USD`), mobile-responsive single-page web application built for **GitHub Pages**. Construct an ideal Manchester United Starting XI across 6 tactical formations, prioritize existing Manchester United squad members or scout across **9 permitted European leagues** via a strict 4-step hierarchical funnel, and evaluate real-time transfer spend, 5-year amortization, and UEFA/Premier League PSR feasibility.

---

## Core Capabilities

1. **Interactive Tactical Pitch & Formation Engine**:
   - Top-down Old Trafford grass pitch with SVG markings and smooth CSS coordinate transitions.
   - Supports **6 formations**: `4-2-3-1`, `3-4-3` (Amorim System), `4-3-3`, `3-5-2`, `4-4-2`, and `5-3-2`.
   - Circular player nodes displaying: (1) Player headshot with custom SVG kit fallback, (2) Positional acronym badge, (3) Surname & club tag, and (4) Market valuation price tag (`£ GBP` / `€ EUR`).

2. **Two-Tier Hierarchical Recruitment Funnel**:
   - **Tier 1 — Manchester United Priority (Default)**: Immediately surfaces eligible active Manchester United squad members (`£0.0M / €0.0M` incremental transfer fee).
   - **Tier 2 — External European Scouting (Strict 4-Step Drill-Down)**: Enforces `Position Locked -> League Selection -> Club Selection -> Player Selection` across the **9 permitted European top flights**:
     - *Top 5 European Leagues*: England (Premier League), Spain (La Liga), Italy (Serie A), Germany (Bundesliga), France (Ligue 1).
     - *Additional Scouting Leagues*: Netherlands (Eredivisie), Portugal (Primeira Liga), Norway (Eliteserien), Denmark (Superliga).

3. **Financial Feasibility & Club Economics Engine**:
   - Real-time calculation of **Total Starting XI Valuation**, **Gross External Transfer Outlay**, and **Net Transfer Spend** (with an interactive **Outgoing MUFC Squad Sales Simulator**).
   - Computes **5-Year Annualized Contract Amortization** (per Premier League & UEFA 60-month cap rules), **Net Annual Wage Impact**, and **UEFA Squad Cost Ratio (%)** against Manchester United's `£660M` revenue baseline.

---

## Repository Structure

```text
manchester-united-engine/
├── index.html                        # Standalone SPA (HTML5 + Tailwind CSS + Vanilla JS)
├── data/
│   ├── leagues.json                  # 9 permitted European leagues metadata
│   ├── teams.json                    # 56 clubs across the 9 leagues
│   └── players.json                  # 190 players (MUFC squad + external targets)
├── scripts/
│   └── fetch_market_data.py          # Zero-cost Python valuation & squad sync pipeline
├── .github/
│   └── workflows/
│       └── deploy.yml                # Weekly cron refresh + automated GitHub Pages deployment
└── README.md
```

---

## How to Upload & Deploy to GitHub Pages ($0 Cost)

1. Create a new public repository on GitHub (e.g., `mufc-ideal-11-engine`).
2. Upload or push this folder to the `main` branch:
   ```bash
   git init
   git add .
   git commit -m "feat: initial Manchester United Ideal 11 & Financial Feasibility Engine"
   git branch -M main
   git remote add origin https://github.com/<your-username>/mufc-ideal-11-engine.git
   git push -u origin main
   ```
3. In your GitHub repository, navigate to **Settings -> Pages**:
   - Under **Build and deployment -> Source**, select **GitHub Actions** (or **Deploy from a branch -> `main` / `/ (root)`**).
4. The workflow in `.github/workflows/deploy.yml` will automatically deploy the site to `https://<your-username>.github.io/mufc-ideal-11-engine/` and refresh market data every Monday at 06:00 UTC.
